export interface Monastery {
    id: number;
    name: string;
    lat: number;
    lng: number;
    type: string;
    visitors: number;
    description: string;
    founded?: string;
    sect?: string;
    altitude?: string;
    features: string[];
    nearbyAttractions: string[];
    openingHours?: string;
    contact?: string;
}

export const sikkimMonasteries: Monastery[] = [
    {
        id: 1,
        name: 'Rumtek Monastery',
        lat: 27.2985,
        lng: 88.6167,
        type: 'Tibetan Buddhist',
        visitors: 1500,
        description: 'Rumtek Monastery, also known as the Dharma Chakra Centre, is one of the most important and largest monasteries in Sikkim. It serves as the seat of the 17th Karmapa and is a center for Kagyu Buddhism. The monastery houses precious artifacts, thangka paintings, and a magnificent golden stupa. It offers breathtaking views of Gangtok and the surrounding mountains.',
        founded: '1966',
        sect: 'Kagyu',
        altitude: '5,500 ft',
        features: ['Golden stupa', 'Thangka paintings', 'Prayer wheels', 'Monastic education center', 'Sacred relics', 'Meditation halls', 'Library with ancient texts'],
        nearbyAttractions: ['Rumtek village', 'Sikkim University', 'Gangtok city', 'Enchey Monastery'],
        openingHours: '6:00 AM - 6:00 PM',
        contact: '+91-3592-247030'
    },
    {
        id: 2,
        name: 'Pemayangtse Monastery',
        lat: 27.3083,
        lng: 88.2244,
        type: 'Tibetan Buddhist',
        visitors: 1200,
        description: 'Pemayangtse Monastery is one of the oldest and most important monasteries in Sikkim, belonging to the Nyingma sect. Founded in 1705, it is renowned for its magnificent architecture, ancient manuscripts, and the famous seven-tiered wooden model of the celestial palace. The monastery offers stunning views of Mount Kanchenjunga and houses precious Buddhist artifacts.',
        founded: '1705',
        sect: 'Nyingma',
        altitude: '6,840 ft',
        features: ['Seven-tiered wooden model', 'Ancient manuscripts', 'Sacred relics', 'Monastic school', 'Thangka collection', 'Prayer hall', 'Stupa garden'],
        nearbyAttractions: ['Rabdentse ruins', 'Pelling', 'Kanchenjunga view', 'Sangachoeling Monastery', 'Tashiding Monastery'],
        openingHours: '6:00 AM - 6:00 PM',
        contact: '+91-3595-258004'
    },
    {
        id: 3,
        name: 'Tashiding Monastery',
        lat: 27.3667,
        lng: 88.3167,
        type: 'Tibetan Buddhist',
        visitors: 800,
        description: 'Tashiding Monastery is one of the most sacred monasteries in Sikkim, famous for its annual Bumchu (sacred water) festival. Located on a hilltop, it offers panoramic views of the surrounding mountains and valleys. The monastery is renowned for its ancient stupas, prayer flags, and the sacred water ceremony that attracts thousands of devotees annually.',
        founded: '1641',
        sect: 'Nyingma',
        altitude: '4,500 ft',
        features: ['Sacred water ceremony', 'Ancient stupas', 'Prayer flags', 'Mountain views', 'Bumchu festival', 'Meditation caves', 'Sacred spring'],
        nearbyAttractions: ['Tashiding village', 'Soreng', 'Gyalshing', 'Yuksom', 'Dubdi Monastery'],
        openingHours: '6:00 AM - 5:00 PM',
        contact: '+91-3595-244035'
    },
    {
        id: 4,
        name: 'Enchey Monastery',
        lat: 27.3306,
        lng: 88.6167,
        type: 'Tibetan Buddhist',
        visitors: 1000,
        description: 'Enchey Monastery is a beautiful monastery located in Gangtok, famous for its annual Chaam (masked dance) festival. Built in 1909, it belongs to the Nyingma sect and is known for its peaceful atmosphere and stunning city views. The monastery features traditional Tibetan architecture and houses ancient Buddhist scriptures and artifacts.',
        founded: '1909',
        sect: 'Nyingma',
        altitude: '5,500 ft',
        features: ['Chaam dance festival', 'Peaceful garden', 'Prayer wheels', 'City views', 'Traditional architecture', 'Ancient scriptures', 'Meditation hall'],
        nearbyAttractions: ['Gangtok city', 'MG Marg', 'Namgyal Institute', 'Rumtek Monastery', 'Tsuk La Khang'],
        openingHours: '6:00 AM - 6:00 PM',
        contact: '+91-3592-232042'
    },
    {
        id: 5,
        name: 'Dubdi Monastery',
        lat: 27.3167,
        lng: 88.2167,
        type: 'Tibetan Buddhist',
        visitors: 600,
        description: 'Dubdi Monastery, also known as Yuksom Monastery, is the oldest monastery in Sikkim, founded in 1701 by Lhatsun Chenpo. Located in Yuksom, it offers a peaceful retreat with immense historical significance. The monastery is accessible by a scenic trek through dense forests and offers breathtaking views of the surrounding mountains.',
        founded: '1701',
        sect: 'Nyingma',
        altitude: '7,000 ft',
        features: ['Ancient architecture', 'Historical significance', 'Peaceful setting', 'Mountain trails', 'Sacred texts', 'Meditation caves', 'Forest trek'],
        nearbyAttractions: ['Yuksom', 'Norbugang Coronation Throne', 'Kanchenjunga National Park', 'Khecheopalri Lake', 'Tashiding Monastery'],
        openingHours: '6:00 AM - 5:00 PM',
        contact: '+91-3595-245006'
    },
    {
        id: 6,
        name: 'Phodong Monastery',
        lat: 27.4333,
        lng: 88.5667,
        type: 'Tibetan Buddhist',
        visitors: 700,
        description: 'Phodong Monastery is a beautiful monastery in North Sikkim known for its traditional Tibetan architecture and serene environment. Founded in 1740, it belongs to the Kagyu sect and serves as an important religious center for the local community. The monastery offers a peaceful retreat with stunning mountain views.',
        founded: '1740',
        sect: 'Kagyu',
        altitude: '4,500 ft',
        features: ['Traditional architecture', 'Peaceful environment', 'Prayer flags', 'Local community', 'Mountain views', 'Sacred texts', 'Meditation halls'],
        nearbyAttractions: ['Mangan', 'Lachung', 'Yumthang Valley', 'Lachung Monastery', 'North Sikkim'],
        openingHours: '6:00 AM - 5:00 PM',
        contact: '+91-3592-234567'
    },
    {
        id: 7,
        name: 'Lachung Monastery',
        lat: 27.6833,
        lng: 88.7500,
        type: 'Tibetan Buddhist',
        visitors: 500,
        description: 'Lachung Monastery is located in the scenic Lachung valley at a high altitude, offering stunning mountain views and a peaceful retreat experience. Founded in 1880, it belongs to the Nyingma sect and is surrounded by snow-capped peaks and pristine natural beauty.',
        founded: '1880',
        sect: 'Nyingma',
        altitude: '8,600 ft',
        features: ['Mountain views', 'Peaceful retreat', 'Local culture', 'High altitude experience', 'Snow-capped peaks', 'Traditional architecture', 'Sacred artifacts'],
        nearbyAttractions: ['Yumthang Valley', 'Zero Point', 'Lachung village', 'Phodong Monastery', 'North Sikkim'],
        openingHours: '6:00 AM - 5:00 PM',
        contact: '+91-3592-245678'
    },
    {
        id: 8,
        name: 'Ralang Monastery',
        lat: 27.2833,
        lng: 88.3833,
        type: 'Tibetan Buddhist',
        visitors: 400,
        description: 'Ralang Monastery is a lesser-known gem in South Sikkim, offering an authentic monastic experience away from tourist crowds. Founded in 1768, it belongs to the Kagyu sect and provides a peaceful atmosphere for meditation and spiritual practices. The monastery is surrounded by lush greenery and offers a genuine insight into traditional Buddhist practices.',
        founded: '1768',
        sect: 'Kagyu',
        altitude: '4,000 ft',
        features: ['Authentic experience', 'Traditional practices', 'Local community', 'Peaceful atmosphere', 'Lush greenery', 'Sacred texts', 'Meditation practices'],
        nearbyAttractions: ['Ravangla', 'Temi Tea Garden', 'Namchi', 'South Sikkim', 'Buddha Park'],
        openingHours: '6:00 AM - 5:00 PM',
        contact: '+91-3595-267890'
    }
];
