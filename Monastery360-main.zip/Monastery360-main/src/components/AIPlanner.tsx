import { Send, Bot, User, MapPin, Calendar, DollarSign, Clock, Menu, ArrowLeft } from 'lucide-react';
import { Card, CardContent } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Badge } from './ui/badge';
import { ScrollArea } from './ui/scroll-area';
import { Slider } from './ui/slider';
import { useState } from 'react';

interface AIPlannerProps {
  onMenuClick: () => void;
  onBackClick: () => void;
}

export function AIPlanner({ onMenuClick, onBackClick }: AIPlannerProps) {
  const [messages] = useState([
    {
      id: 1,
      type: 'bot',
      content: "Welcome! I'm your AI spiritual journey planner. I can help you create personalized monastery visits, meditation retreats, and cultural experiences. What kind of journey are you seeking?",
      timestamp: '2:34 PM'
    },
    {
      id: 2,
      type: 'user',
      content: "I'd like to plan a 7-day meditation retreat in Tibet, focusing on mindfulness and traditional Buddhist practices.",
      timestamp: '2:35 PM'
    },
    {
      id: 3,
      type: 'bot',
      content: "Perfect! I'll create a personalized 7-day Tibet meditation retreat for you. Let me gather some preferences first.",
      timestamp: '2:35 PM'
    }
  ]);

  const [budget, setBudget] = useState([2500]);
  const [duration, setDuration] = useState([7]);

  const suggestions = [
    "Plan a weekend temple visit",
    "Cultural heritage tour",
    "Meditation retreat planning",
    "Festival calendar recommendations"
  ];

  const planningSteps = [
    { icon: MapPin, label: 'Destinations', status: 'completed' },
    { icon: Calendar, label: 'Schedule', status: 'active' },
    { icon: DollarSign, label: 'Budget', status: 'pending' },
    { icon: Clock, label: 'Activities', status: 'pending' }
  ];

  return (
    <div className="pb-20 min-h-screen bg-[#F4F1DE] flex flex-col">
      {/* Header */}
      <div className="bg-gradient-to-r from-[#3D405B] to-[#E07A5F] px-6 py-4 relative">
        <div className="flex items-center gap-2 absolute top-2 left-4">
          <Button
            variant="ghost"
            size="sm"
            onClick={onMenuClick}
            className="text-white hover:bg-white/20"
          >
            <Menu size={20} />
          </Button>
          <Button
            variant="ghost"
            size="sm"
            onClick={onBackClick}
            className="text-white hover:bg-white/20"
          >
            <ArrowLeft size={20} />
          </Button>
        </div>
        <div className="mt-10">
          <h1 className="text-white text-xl font-bold mb-1">AI Trip Planner</h1>
          <p className="text-white/80 text-sm">Personalized spiritual journey planning</p>
        </div>
      </div>

      {/* Planning Progress */}
      <div className="bg-white/90 backdrop-blur-lg px-6 py-4 border-b border-[#3D405B]/10">
        <div className="flex items-center justify-between">
          {planningSteps.map((step, index) => {
            const Icon = step.icon;
            return (
              <div key={step.label} className="flex flex-col items-center">
                <div className={`w-8 h-8 rounded-full flex items-center justify-center mb-1 ${
                  step.status === 'completed' ? 'bg-[#E07A5F] text-white' :
                  step.status === 'active' ? 'bg-[#F2CC8F] text-[#3D405B]' :
                  'bg-[#F4F1DE] text-[#3D405B]/60'
                }`}>
                  <Icon size={16} />
                </div>
                <span className={`text-xs ${
                  step.status === 'active' ? 'text-[#3D405B] font-medium' : 'text-[#3D405B]/60'
                }`}>
                  {step.label}
                </span>
              </div>
            );
          })}
        </div>
      </div>

      {/* Chat Messages */}
      <ScrollArea className="flex-1 px-6 py-4">
        <div className="space-y-4 pb-4">
          {messages.map((message) => (
            <div key={message.id} className={`flex ${message.type === 'user' ? 'justify-end' : 'justify-start'}`}>
              <div className={`flex max-w-[80%] ${message.type === 'user' ? 'flex-row-reverse' : 'flex-row'}`}>
                <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
                  message.type === 'user' ? 'bg-[#E07A5F] ml-2' : 'bg-[#F2CC8F] mr-2'
                }`}>
                  {message.type === 'user' ? 
                    <User size={16} className="text-white" /> : 
                    <Bot size={16} className="text-[#3D405B]" />
                  }
                </div>
                <div className={`rounded-lg p-3 ${
                  message.type === 'user' 
                    ? 'bg-[#E07A5F] text-white' 
                    : 'monastery-card monastery-shadow text-[#3D405B]'
                }`}>
                  <p className="text-sm">{message.content}</p>
                  <p className={`text-xs mt-1 ${
                    message.type === 'user' ? 'text-white/70' : 'text-[#3D405B]/60'
                  }`}>
                    {message.timestamp}
                  </p>
                </div>
              </div>
            </div>
          ))}

          {/* Current Planning Card */}
          <Card className="monastery-card monastery-shadow">
            <CardContent className="p-4">
              <h4 className="text-[#3D405B] font-medium mb-3 flex items-center">
                <Bot className="text-[#E07A5F] mr-2" size={16} />
                Let's customize your retreat
              </h4>
              
              <div className="space-y-4">
                <div>
                  <label className="text-[#3D405B] text-sm font-medium mb-2 block">
                    Budget Range: ${budget[0].toLocaleString()}
                  </label>
                  <Slider
                    value={budget}
                    onValueChange={setBudget}
                    max={5000}
                    min={500}
                    step={100}
                    className="w-full"
                  />
                  <div className="flex justify-between text-xs text-[#3D405B]/60 mt-1">
                    <span>$500</span>
                    <span>$5,000</span>
                  </div>
                </div>

                <div>
                  <label className="text-[#3D405B] text-sm font-medium mb-2 block">
                    Duration: {duration[0]} days
                  </label>
                  <Slider
                    value={duration}
                    onValueChange={setDuration}
                    max={30}
                    min={1}
                    step={1}
                    className="w-full"
                  />
                  <div className="flex justify-between text-xs text-[#3D405B]/60 mt-1">
                    <span>1 day</span>
                    <span>30 days</span>
                  </div>
                </div>

                <div className="flex flex-wrap gap-2">
                  <Badge className="bg-[#F2CC8F]/30 text-[#3D405B]">Meditation</Badge>
                  <Badge className="bg-[#F2CC8F]/30 text-[#3D405B]">Cultural Tours</Badge>
                  <Badge className="bg-[#F2CC8F]/30 text-[#3D405B]">Mountain Views</Badge>
                </div>

                <Button className="w-full bg-[#E07A5F] hover:bg-[#E07A5F]/90 text-white">
                  Generate Custom Plan
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </ScrollArea>

      {/* Quick Suggestions */}
      <div className="px-6 py-2 bg-white/90 backdrop-blur-lg border-t border-[#3D405B]/10">
        <div className="flex space-x-2 overflow-x-auto pb-2">
          {suggestions.map((suggestion) => (
            <Button
              key={suggestion}
              variant="outline"
              size="sm"
              className="whitespace-nowrap border-[#3D405B]/20 text-[#3D405B] text-xs"
            >
              {suggestion}
            </Button>
          ))}
        </div>
      </div>

      {/* Input Area */}
      <div className="px-6 py-4 bg-white/90 backdrop-blur-lg border-t border-[#3D405B]/10">
        <div className="flex space-x-2">
          <Input 
            placeholder="Ask about destinations, budgets, or activities..."
            className="flex-1 bg-[#F4F1DE]/50 border-[#3D405B]/20"
          />
          <Button className="bg-[#E07A5F] hover:bg-[#E07A5F]/90 text-white">
            <Send size={16} />
          </Button>
        </div>
      </div>
    </div>
  );
}