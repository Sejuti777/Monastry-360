import { Play, Eye, Clock, Star, VolumeX, Volume2, RotateCcw, Maximize, Menu, ArrowLeft } from 'lucide-react';
import { Card, CardContent } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { ImageWithFallback } from './figma/ImageWithFallback';

interface ToursScreenProps {
  onMenuClick: () => void;
  onBackClick: () => void;
}

export function ToursScreen({ onMenuClick, onBackClick }: ToursScreenProps) {
  const tours = [
    {
      id: 1,
      title: 'Meditation Hall Experience',
      monastery: 'Drepung Monastery',
      duration: '8:30',
      views: 15420,
      rating: 4.9,
      image: 'https://images.unsplash.com/photo-1643454743783-ceaf41d5efdd?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtb25hc3RlcnklMjBpbnRlcmlvciUyMG1lZGl0YXRpb24lMjBoYWxsfGVufDF8fHx8MTc1NzgzNDM4Mnww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
      featured: true,
      description: 'Immerse yourself in the sacred atmosphere of morning prayers'
    },
    {
      id: 2,
      title: 'Sacred Architecture Tour',
      monastery: 'Jokhang Temple',
      duration: '12:15',
      views: 8930,
      rating: 4.8,
      image: 'https://images.unsplash.com/photo-1565195161077-f5c5f61f9ea2?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx0ZW1wbGUlMjBhcmNoaXRlY3R1cmUlMjBzcGlyaXR1YWx8ZW58MXx8fHwxNzU3ODM0Mzg1fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
      featured: false,
      description: 'Explore the intricate details of traditional temple architecture'
    },
    {
      id: 3,
      title: 'Garden Meditation Walk',
      monastery: 'Sera Monastery',
      duration: '6:45',
      views: 5620,
      rating: 4.7,
      image: 'https://images.unsplash.com/photo-1629646621053-458c7ab125a9?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx0aWJldGFuJTIwbW9uYXN0ZXJ5JTIwbW91bnRhaW58ZW58MXx8fHwxNzU3ODM0MzI1fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
      featured: false,
      description: 'Peaceful walk through monastery gardens with mountain views'
    }
  ];

  const categories = ['Featured', 'Meditation', 'Architecture', 'Ceremonies', 'Nature'];

  return (
    <div className="pb-20 min-h-screen bg-[#F4F1DE]">
      {/* Header */}
      <div className="bg-gradient-to-r from-[#3D405B] to-[#E07A5F] px-6 py-6 relative">
        <div className="flex items-center gap-2 absolute top-2 left-4">
          <Button
            variant="ghost"
            size="sm"
            onClick={onMenuClick}
            className="text-white hover:bg-white/20"
          >
            <Menu size={20} />
          </Button>
          <Button
            variant="ghost"
            size="sm"
            onClick={onBackClick}
            className="text-white hover:bg-white/20"
          >
            <ArrowLeft size={20} />
          </Button>
        </div>
        <div className="mt-10">
          <h1 className="text-white text-2xl font-bold mb-2">360° Virtual Tours</h1>
          <p className="text-white/80 text-sm">Immersive spiritual experiences from around the world</p>
        </div>
      </div>

      {/* Categories */}
      <div className="px-6 py-4 bg-white/90 backdrop-blur-lg border-b border-[#3D405B]/10">
        <div className="flex space-x-2 overflow-x-auto pb-2">
          {categories.map((category, index) => (
            <Badge 
              key={category} 
              variant={index === 0 ? "default" : "secondary"}
              className={`whitespace-nowrap ${
                index === 0 
                  ? 'bg-[#E07A5F] text-white hover:bg-[#E07A5F]/90' 
                  : 'bg-[#F2CC8F]/30 text-[#3D405B] hover:bg-[#F2CC8F]/50'
              }`}
            >
              {category}
            </Badge>
          ))}
        </div>
      </div>

      {/* Featured Tour */}
      <div className="px-6 py-4">
        <h3 className="text-[#3D405B] mb-4">Featured Experience</h3>
        <Card className="monastery-card monastery-shadow overflow-hidden">
          <CardContent className="p-0">
            <div className="relative">
              <ImageWithFallback 
                src={tours[0].image}
                alt={tours[0].title}
                className="w-full h-48 object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent"></div>
              <div className="absolute bottom-4 left-4 right-4">
                <Badge className="bg-[#F2CC8F] text-[#3D405B] mb-2">Featured</Badge>
                <h4 className="text-white font-medium mb-1">{tours[0].title}</h4>
                <p className="text-white/80 text-sm">{tours[0].monastery}</p>
              </div>
              <div className="absolute center top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2">
                <Button size="lg" className="rounded-full w-16 h-16 bg-white/20 backdrop-blur-sm border-2 border-white/30 hover:bg-white/30">
                  <Play className="text-white ml-1" size={24} />
                </Button>
              </div>
              {/* 360° Indicator */}
              <div className="absolute top-4 right-4 bg-[#E07A5F] text-white px-2 py-1 rounded-full text-xs font-medium">
                360°
              </div>
            </div>
            <div className="p-4">
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center space-x-3">
                  <div className="flex items-center space-x-1">
                    <Clock className="text-[#3D405B]/60" size={14} />
                    <span className="text-[#3D405B]/80 text-sm">{tours[0].duration}</span>
                  </div>
                  <div className="flex items-center space-x-1">
                    <Eye className="text-[#3D405B]/60" size={14} />
                    <span className="text-[#3D405B]/80 text-sm">{tours[0].views.toLocaleString()}</span>
                  </div>
                </div>
                <div className="flex items-center space-x-1">
                  <Star className="text-[#F2CC8F] fill-current" size={14} />
                  <span className="text-[#3D405B] text-sm">{tours[0].rating}</span>
                </div>
              </div>
              <p className="text-[#3D405B]/80 text-sm accent-text">{tours[0].description}</p>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Tour List */}
      <div className="px-6">
        <h3 className="text-[#3D405B] mb-4">More Tours</h3>
        <div className="space-y-4">
          {tours.slice(1).map((tour) => (
            <Card key={tour.id} className="monastery-card monastery-shadow">
              <CardContent className="p-0">
                <div className="flex">
                  <div className="relative w-28 h-20 rounded-l-lg overflow-hidden">
                    <ImageWithFallback 
                      src={tour.image}
                      alt={tour.title}
                      className="w-full h-full object-cover"
                    />
                    <div className="absolute inset-0 bg-black/20 flex items-center justify-center">
                      <Play className="text-white" size={16} />
                    </div>
                    <div className="absolute top-1 right-1 bg-[#E07A5F] text-white px-1 py-0.5 rounded text-xs">
                      360°
                    </div>
                  </div>
                  <div className="flex-1 p-3">
                    <h4 className="text-[#3D405B] font-medium text-sm mb-1">{tour.title}</h4>
                    <p className="text-[#3D405B]/60 text-xs mb-2">{tour.monastery}</p>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-2">
                        <span className="text-[#3D405B]/80 text-xs">{tour.duration}</span>
                        <span className="text-[#3D405B]/60 text-xs">•</span>
                        <div className="flex items-center space-x-1">
                          <Star className="text-[#F2CC8F] fill-current" size={10} />
                          <span className="text-[#3D405B]/80 text-xs">{tour.rating}</span>
                        </div>
                      </div>
                      <Button size="sm" variant="outline" className="border-[#E07A5F] text-[#E07A5F] h-6 text-xs">
                        Watch
                      </Button>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>

      {/* Controls Bar (for when viewing a tour) */}
      <div className="fixed bottom-20 left-0 right-0 bg-black/80 backdrop-blur-lg text-white px-6 py-3 hidden">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <Button size="sm" variant="ghost" className="text-white">
              <VolumeX size={16} />
            </Button>
            <Button size="sm" variant="ghost" className="text-white">
              <RotateCcw size={16} />
            </Button>
          </div>
          <div className="text-center">
            <p className="text-xs">Meditation Hall Experience</p>
            <p className="text-xs text-white/60">2:35 / 8:30</p>
          </div>
          <div className="flex items-center space-x-4">
            <Button size="sm" variant="ghost" className="text-white">
              <Maximize size={16} />
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}