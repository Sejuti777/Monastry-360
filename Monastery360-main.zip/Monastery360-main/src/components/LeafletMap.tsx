import React, { useState, useEffect } from 'react';
import { MapContainer, TileLayer, Marker, Popup, useMap } from 'react-leaflet';
import { Icon } from 'leaflet';
import { MapPin, Users, Mountain, Clock, Phone, Navigation } from 'lucide-react';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { sikkimMonasteries, Monastery } from '../data/monasteries';

// Fix for default markers in react-leaflet - using CDN URLs to avoid import issues
delete (Icon.Default.prototype as any)._getIconUrl;
Icon.Default.mergeOptions({
    iconRetinaUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/images/marker-icon-2x.png',
    iconUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/images/marker-icon.png',
    shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/images/marker-shadow.png',
});

interface LeafletMapProps {
    selectedMonastery?: Monastery | null;
    onMonasterySelect?: (monastery: Monastery) => void;
    userLocation?: { lat: number; lng: number } | null;
    searchQuery?: string;
    filteredMonasteries?: Monastery[];
}

// Custom component to fit bounds when monasteries change
function FitBounds({ monasteries }: { monasteries: Monastery[] }) {
    const map = useMap();

    useEffect(() => {
        if (monasteries.length > 0) {
            const bounds = monasteries.map(monastery => [monastery.lat, monastery.lng] as [number, number]);
            map.fitBounds(bounds, { padding: [20, 20] });
        }
    }, [map, monasteries]);

    return null;
}

// Custom component to handle selected monastery
function SelectedMonasteryHandler({ selectedMonastery }: { selectedMonastery: Monastery | null }) {
    const map = useMap();

    useEffect(() => {
        if (selectedMonastery) {
            map.setView([selectedMonastery.lat, selectedMonastery.lng], 15);
        }
    }, [map, selectedMonastery]);

    return null;
}

// Create custom monastery marker icon
const createMonasteryIcon = (color: string = '#E07A5F') => {
    return new Icon({
        iconUrl: `data:image/svg+xml;base64,${btoa(`
      <svg width="40" height="48" viewBox="0 0 40 48" fill="none" xmlns="http://www.w3.org/2000/svg">
        <!-- Shadow -->
        <ellipse cx="20" cy="46" rx="8" ry="3" fill="rgba(0,0,0,0.3)"/>
        <!-- Main building -->
        <rect x="10" y="20" width="20" height="16" fill="${color}" stroke="white" stroke-width="3" rx="3"/>
        <!-- Roof -->
        <polygon points="8,20 20,10 32,20" fill="${color}" stroke="white" stroke-width="3"/>
        <!-- Door -->
        <rect x="17" y="26" width="6" height="10" fill="white" rx="2"/>
        <!-- Windows -->
        <rect x="12" y="23" width="3" height="3" fill="white"/>
        <rect x="25" y="23" width="3" height="3" fill="white"/>
        <!-- Flag -->
        <line x1="20" y1="10" x2="20" y2="6" stroke="white" stroke-width="3"/>
        <circle cx="20" cy="6" r="3" fill="white"/>
      </svg>
    `)}`,
        iconSize: [40, 48],
        iconAnchor: [20, 48],
        popupAnchor: [0, -48],
    });
};

// Create user location marker icon
const createUserIcon = () => {
    return new Icon({
        iconUrl: `data:image/svg+xml;base64,${btoa(`
      <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
        <circle cx="8" cy="8" r="6" fill="#3D405B" stroke="white" stroke-width="2"/>
        <circle cx="8" cy="8" r="2" fill="white"/>
      </svg>
    `)}`,
        iconSize: [16, 16],
        iconAnchor: [8, 8],
    });
};

const LeafletMap: React.FC<LeafletMapProps> = ({
    selectedMonastery,
    onMonasterySelect,
    userLocation,
    searchQuery,
    filteredMonasteries
}) => {
    const [mapCenter] = useState<[number, number]>([27.3333, 88.6167]); // Center of Sikkim
    const [mapZoom] = useState(9);

    const monasteriesToShow = filteredMonasteries || sikkimMonasteries;

    // Add debug logging
    console.log('LeafletMap rendering with:', { monasteriesToShow: monasteriesToShow.length, mapCenter, mapZoom });

    // Add a loading state
    const [isLoading, setIsLoading] = useState(true);

    return (
        <div className="w-full h-full rounded-lg overflow-hidden" style={{ minHeight: '400px' }}>
            {isLoading && (
                <div className="absolute inset-0 flex items-center justify-center bg-gradient-to-br from-[#F2CC8F]/20 to-[#E07A5F]/10 z-10">
                    <div className="text-center">
                        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-[#E07A5F] mx-auto mb-2"></div>
                        <p className="text-[#3D405B] text-sm">Loading map...</p>
                    </div>
                </div>
            )}
            <MapContainer
                center={mapCenter}
                zoom={mapZoom}
                className="w-full h-full"
                style={{ height: '400px', width: '100%' }}
                whenReady={() => setIsLoading(false)}
            >
                {/* OpenStreetMap tiles - completely free */}
                <TileLayer
                    attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
                    url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
                />

                {/* Fit bounds to show all monasteries */}
                <FitBounds monasteries={monasteriesToShow} />

                {/* Handle selected monastery */}
                <SelectedMonasteryHandler selectedMonastery={selectedMonastery || null} />

                {/* Monastery markers */}
                {monasteriesToShow.map((monastery) => (
                    <Marker
                        key={monastery.id}
                        position={[monastery.lat, monastery.lng]}
                        icon={createMonasteryIcon()}
                        eventHandlers={{
                            click: () => {
                                console.log('Monastery marker clicked:', monastery.name);
                                if (onMonasterySelect) {
                                    onMonasterySelect(monastery);
                                }
                            },
                        }}
                    >
                        <Popup>
                            <div style={{ padding: '10px', minWidth: '200px' }}>
                                <h3 style={{ margin: '0 0 8px 0', fontSize: '16px', fontWeight: 'bold', color: '#3D405B' }}>
                                    {monastery.name}
                                </h3>
                                <p style={{ margin: '0 0 8px 0', fontSize: '14px', color: '#3D405B' }}>
                                    {monastery.type}
                                </p>
                                <p style={{ margin: '0 0 8px 0', fontSize: '12px', color: '#3D405B' }}>
                                    {monastery.description.substring(0, 100)}...
                                </p>
                                <div style={{ display: 'flex', gap: '8px', marginTop: '10px' }}>
                                    <button
                                        style={{
                                            backgroundColor: '#E07A5F',
                                            color: 'white',
                                            border: 'none',
                                            padding: '6px 12px',
                                            borderRadius: '4px',
                                            fontSize: '12px',
                                            cursor: 'pointer'
                                        }}
                                        onClick={() => {
                                            console.log('View Details clicked for:', monastery.name);
                                            if (onMonasterySelect) {
                                                onMonasterySelect(monastery);
                                            }
                                        }}
                                    >
                                        View Details
                                    </button>
                                    <button
                                        style={{
                                            backgroundColor: 'transparent',
                                            color: '#3D405B',
                                            border: '1px solid #3D405B',
                                            padding: '6px 12px',
                                            borderRadius: '4px',
                                            fontSize: '12px',
                                            cursor: 'pointer'
                                        }}
                                        onClick={() => {
                                            console.log('Route clicked for:', monastery.name);
                                            const url = `https://www.google.com/maps/dir/?api=1&destination=${monastery.lat},${monastery.lng}`;
                                            window.open(url, '_blank');
                                        }}
                                    >
                                        Route
                                    </button>
                                </div>
                            </div>
                        </Popup>
                    </Marker>
                ))}

                {/* User location marker */}
                {userLocation && (
                    <Marker
                        position={[userLocation.lat, userLocation.lng]}
                        icon={createUserIcon()}
                    >
                        <Popup>
                            <div className="p-2 text-center">
                                <div className="flex items-center justify-center space-x-2 mb-1">
                                    <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                                    <span className="font-medium text-sm">Your Location</span>
                                </div>
                                <p className="text-xs text-gray-600">
                                    {userLocation.lat.toFixed(4)}, {userLocation.lng.toFixed(4)}
                                </p>
                            </div>
                        </Popup>
                    </Marker>
                )}
            </MapContainer>

        </div>
    );
};

export default LeafletMap;
