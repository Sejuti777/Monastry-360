import { Trophy, Medal, Star, MapPin, Camera, Calendar, MessageCircle, Heart, Menu, ArrowLeft } from 'lucide-react';
import { Card, CardContent } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from './ui/avatar';
import { Progress } from './ui/progress';

interface CommunityScreenProps {
  onMenuClick: () => void;
  onBackClick: () => void;
}

export function CommunityScreen({ onMenuClick, onBackClick }: CommunityScreenProps) {
  const leaderboard = [
    {
      id: 1,
      name: 'Tenzin Norbu',
      avatar: 'https://images.unsplash.com/photo-1620503397144-26764efd6abd?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtZWRpdGF0aW9uJTIwc3Bpcml0dWFsJTIwcGVvcGxlfGVufDF8fHx8MTc1NzgzNDQ4NXww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
      points: 2840,
      rank: 1,
      badge: 'Enlightened Explorer',
      visits: 45,
      country: 'Tibet'
    },
    {
      id: 2,
      name: 'Sarah Chen',
      avatar: null,
      points: 2650,
      rank: 2,
      badge: 'Sacred Seeker',
      visits: 38,
      country: 'USA'
    },
    {
      id: 3,
      name: 'Karma Patel',
      avatar: null,
      points: 2420,
      rank: 3,
      badge: 'Temple Guardian',
      visits: 32,
      country: 'India'
    },
    {
      id: 4,
      name: 'Alex Johnson',
      avatar: null,
      points: 2180,
      rank: 4,
      badge: 'Peaceful Pilgrim',
      visits: 28,
      country: 'Canada'
    },
    {
      id: 5,
      name: 'Maria Santos',
      avatar: null,
      points: 1950,
      rank: 5,
      badge: 'Mindful Wanderer',
      visits: 24,
      country: 'Spain'
    }
  ];

  const achievements = [
    { name: 'First Visit', icon: MapPin, unlocked: true, description: 'Visited your first monastery' },
    { name: 'Photo Master', icon: Camera, unlocked: true, description: 'Shared 10 monastery photos' },
    { name: 'Event Attendee', icon: Calendar, unlocked: true, description: 'Attended 5 spiritual events' },
    { name: 'Community Helper', icon: MessageCircle, unlocked: false, description: 'Help 50 travelers plan trips' },
    { name: 'Sacred Scholar', icon: Star, unlocked: false, description: 'Complete 100 virtual tours' },
    { name: 'Global Explorer', icon: Trophy, unlocked: false, description: 'Visit monasteries in 10 countries' }
  ];

  const recentActivity = [
    {
      id: 1,
      user: 'Sarah Chen',
      action: 'completed a virtual tour',
      target: 'Drepung Monastery',
      time: '2 hours ago',
      points: 50
    },
    {
      id: 2,
      user: 'Karma Patel',
      action: 'shared a photo from',
      target: 'Jokhang Temple',
      time: '5 hours ago',
      points: 25
    },
    {
      id: 3,
      user: 'Alex Johnson',
      action: 'joined the event',
      target: 'Full Moon Ceremony',
      time: '1 day ago',
      points: 75
    }
  ];

  const currentUser = {
    name: 'You',
    points: 1650,
    rank: 12,
    nextRankPoints: 1950,
    level: 'Mindful Explorer'
  };

  const progress = (currentUser.points / currentUser.nextRankPoints) * 100;

  return (
    <div className="pb-20 min-h-screen bg-[#F4F1DE]">
      {/* Header */}
      <div className="bg-gradient-to-r from-[#3D405B] to-[#E07A5F] px-6 py-6 relative">
        <div className="flex items-center gap-2 absolute top-2 left-4">
          <Button
            variant="ghost"
            size="sm"
            onClick={onMenuClick}
            className="text-white hover:bg-white/20"
          >
            <Menu size={20} />
          </Button>
          <Button
            variant="ghost"
            size="sm"
            onClick={onBackClick}
            className="text-white hover:bg-white/20"
          >
            <ArrowLeft size={20} />
          </Button>
        </div>
        <div className="mt-10">
          <h1 className="text-white text-2xl font-bold mb-2">Community</h1>
          <p className="text-white/80 text-sm">Connect with fellow spiritual travelers</p>
        </div>
      </div>

      {/* User Stats */}
      <div className="px-6 py-4">
        <Card className="monastery-card monastery-shadow">
          <CardContent className="p-4">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center space-x-3">
                <Avatar className="w-12 h-12">
                  <AvatarFallback className="bg-[#E07A5F] text-white">Y</AvatarFallback>
                </Avatar>
                <div>
                  <h3 className="text-[#3D405B] font-medium">{currentUser.name}</h3>
                  <Badge className="bg-[#F2CC8F] text-[#3D405B]">{currentUser.level}</Badge>
                </div>
              </div>
              <div className="text-right">
                <div className="text-[#3D405B] font-bold text-lg">{currentUser.points}</div>
                <div className="text-[#3D405B]/60 text-sm">points</div>
              </div>
            </div>
            
            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span className="text-[#3D405B]/80">Rank #{currentUser.rank}</span>
                <span className="text-[#3D405B]/80">Next: {currentUser.nextRankPoints - currentUser.points} pts</span>
              </div>
              <Progress value={progress} className="h-2" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Leaderboard */}
      <div className="px-6 py-2">
        <h3 className="text-[#3D405B] mb-4 flex items-center">
          <Trophy className="text-[#F2CC8F] mr-2" size={20} />
          Global Leaderboard
        </h3>
        
        <div className="space-y-2">
          {leaderboard.map((user) => (
            <Card key={user.id} className={`monastery-card ${user.rank <= 3 ? 'monastery-shadow border-2' : 'monastery-shadow'} ${
              user.rank === 1 ? 'border-[#F2CC8F]' :
              user.rank === 2 ? 'border-[#E5E5E5]' :
              user.rank === 3 ? 'border-[#CD7F32]' : ''
            }`}>
              <CardContent className="p-3">
                <div className="flex items-center space-x-3">
                  <div className="relative">
                    <Avatar className="w-10 h-10">
                      {user.avatar ? (
                        <AvatarImage src={user.avatar} alt={user.name} />
                      ) : (
                        <AvatarFallback className="bg-[#E07A5F] text-white">
                          {user.name.split(' ').map(n => n[0]).join('')}
                        </AvatarFallback>
                      )}
                    </Avatar>
                    {user.rank <= 3 && (
                      <div className={`absolute -top-1 -right-1 w-5 h-5 rounded-full flex items-center justify-center ${
                        user.rank === 1 ? 'bg-[#F2CC8F]' :
                        user.rank === 2 ? 'bg-[#E5E5E5]' :
                        'bg-[#CD7F32]'
                      }`}>
                        {user.rank === 1 ? <Trophy size={12} className="text-[#3D405B]" /> :
                         user.rank === 2 ? <Medal size={12} className="text-gray-600" /> :
                         <Medal size={12} className="text-yellow-600" />}
                      </div>
                    )}
                  </div>
                  
                  <div className="flex-1">
                    <div className="flex items-center justify-between">
                      <div>
                        <h4 className="text-[#3D405B] font-medium text-sm">{user.name}</h4>
                        <p className="text-[#3D405B]/60 text-xs">{user.badge}</p>
                      </div>
                      <div className="text-right">
                        <div className="text-[#3D405B] font-bold">{user.points}</div>
                        <div className="text-[#3D405B]/60 text-xs">{user.visits} visits</div>
                      </div>
                    </div>
                  </div>
                  
                  <div className="text-[#3D405B]/80 font-bold text-lg min-w-[24px] text-center">
                    #{user.rank}
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>

      {/* Achievements */}
      <div className="px-6 py-4">
        <h3 className="text-[#3D405B] mb-4">Your Achievements</h3>
        <div className="grid grid-cols-2 gap-3">
          {achievements.map((achievement) => {
            const Icon = achievement.icon;
            return (
              <Card 
                key={achievement.name} 
                className={`monastery-shadow ${
                  achievement.unlocked ? 'monastery-card' : 'bg-gray-100 border-gray-200'
                }`}
              >
                <CardContent className="p-3 text-center">
                  <div className={`w-10 h-10 rounded-full flex items-center justify-center mx-auto mb-2 ${
                    achievement.unlocked ? 'bg-[#E07A5F]/10' : 'bg-gray-200'
                  }`}>
                    <Icon 
                      className={achievement.unlocked ? 'text-[#E07A5F]' : 'text-gray-400'} 
                      size={20} 
                    />
                  </div>
                  <h4 className={`text-xs font-medium mb-1 ${
                    achievement.unlocked ? 'text-[#3D405B]' : 'text-gray-500'
                  }`}>
                    {achievement.name}
                  </h4>
                  <p className={`text-xs ${
                    achievement.unlocked ? 'text-[#3D405B]/60' : 'text-gray-400'
                  }`}>
                    {achievement.description}
                  </p>
                </CardContent>
              </Card>
            );
          })}
        </div>
      </div>

      {/* Recent Activity */}
      <div className="px-6 pb-4">
        <h3 className="text-[#3D405B] mb-4">Recent Activity</h3>
        <div className="space-y-3">
          {recentActivity.map((activity) => (
            <Card key={activity.id} className="monastery-card monastery-shadow">
              <CardContent className="p-3">
                <div className="flex items-center justify-between">
                  <div className="flex-1">
                    <p className="text-[#3D405B] text-sm">
                      <span className="font-medium">{activity.user}</span>
                      <span className="text-[#3D405B]/80"> {activity.action} </span>
                      <span className="font-medium accent-text">{activity.target}</span>
                    </p>
                    <p className="text-[#3D405B]/60 text-xs mt-1">{activity.time}</p>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Badge className="bg-[#F2CC8F] text-[#3D405B]">+{activity.points}</Badge>
                    <Button size="sm" variant="ghost" className="text-[#E07A5F] p-1">
                      <Heart size={14} />
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </div>
  );
}