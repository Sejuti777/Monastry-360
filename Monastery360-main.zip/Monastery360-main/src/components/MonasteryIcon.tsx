import React from 'react';

interface MonasteryIconProps {
    size?: number;
    className?: string;
}

export const MonasteryIcon: React.FC<MonasteryIconProps> = ({ size = 48, className = "" }) => {
    return (
        <svg
            width={size}
            height={size}
            viewBox="0 0 64 64"
            className={className}
            xmlns="http://www.w3.org/2000/svg"
        >
            {/* Lotus flower background */}
            <g>
                {/* Main lotus petals */}
                <path
                    d="M32 8 C20 8, 12 16, 12 28 C12 36, 16 44, 24 48 C28 46, 32 44, 36 46, 40 48 C48 44, 52 36, 52 28 C52 16, 44 8, 32 8 Z"
                    fill="#F2CC8F"
                    opacity="0.9"
                />
                {/* Left large petal */}
                <path
                    d="M16 24 C8 20, 4 28, 8 36 C12 32, 16 28, 16 24 Z"
                    fill="none"
                    stroke="#E07A5F"
                    strokeWidth="2"
                />
                {/* Right large petal */}
                <path
                    d="M48 24 C56 20, 60 28, 56 36 C52 32, 48 28, 48 24 Z"
                    fill="none"
                    stroke="#E07A5F"
                    strokeWidth="2"
                />
                {/* Top petal */}
                <path
                    d="M32 4 C28 0, 24 4, 24 12 C28 8, 32 8, 36 8 C36 4, 36 0, 32 4 Z"
                    fill="none"
                    stroke="#E07A5F"
                    strokeWidth="2"
                />
                {/* Bottom petal */}
                <path
                    d="M32 56 C28 60, 24 56, 24 48 C28 52, 32 52, 36 52 C36 56, 36 60, 32 56 Z"
                    fill="none"
                    stroke="#E07A5F"
                    strokeWidth="2"
                />
            </g>

            {/* Pagoda */}
            <g>
                {/* Pagoda base */}
                <rect
                    x="26"
                    y="42"
                    width="12"
                    height="8"
                    fill="#E07A5F"
                    rx="1"
                />
                {/* Pagoda entrance (U-shaped arch) */}
                <path
                    d="M28 42 Q32 38, 36 42"
                    fill="none"
                    stroke="#E07A5F"
                    strokeWidth="2"
                />

                {/* Lower tier roof */}
                <path
                    d="M24 38 L32 32 L40 38 L38 40 L26 40 Z"
                    fill="#E07A5F"
                />

                {/* Upper tier roof */}
                <path
                    d="M26 32 L32 28 L38 32 L36 34 L28 34 Z"
                    fill="#E07A5F"
                />

                {/* Pagoda spire */}
                <rect
                    x="30"
                    y="24"
                    width="4"
                    height="8"
                    fill="#E07A5F"
                />

                {/* Spire top */}
                <circle
                    cx="32"
                    cy="22"
                    r="2"
                    fill="#E07A5F"
                />
            </g>
        </svg>
    );
};
