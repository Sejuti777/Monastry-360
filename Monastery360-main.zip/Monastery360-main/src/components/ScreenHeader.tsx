import { Menu } from 'lucide-react';
import { Button } from './ui/button';

interface ScreenHeaderProps {
  title: string;
  subtitle?: string;
  onMenuClick: () => void;
  className?: string;
}

export function ScreenHeader({ title, subtitle, onMenuClick, className = "" }: ScreenHeaderProps) {
  return (
    <div className={`bg-gradient-to-r from-[#3D405B] to-[#E07A5F] px-6 py-6 relative ${className}`}>
      <Button
        variant="ghost"
        size="sm"
        onClick={onMenuClick}
        className="absolute top-4 left-4 text-white hover:bg-white/20"
      >
        <Menu size={20} />
      </Button>
      
      <div className="mt-2">
        <h1 className="text-white text-2xl font-bold mb-2">{title}</h1>
        {subtitle && <p className="text-white/80 text-sm">{subtitle}</p>}
      </div>
    </div>
  );
}