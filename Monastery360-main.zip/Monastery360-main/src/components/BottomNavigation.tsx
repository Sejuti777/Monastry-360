import { Map, Camera, MessageSquare, Calendar, Users } from 'lucide-react';

interface BottomNavigationProps {
  activeTab: string;
  onTabChange: (tab: string) => void;
}

export function BottomNavigation({ activeTab, onTabChange }: BottomNavigationProps) {
  const tabs = [
    { id: 'map', label: 'Map', icon: Map },
    { id: 'tours', label: '360° Tours', icon: Camera },
    { id: 'planner', label: 'AI Planner', icon: MessageSquare },
    { id: 'calendar', label: 'Calendar', icon: Calendar },
    { id: 'community', label: 'Community', icon: Users },
  ];

  return (
    <div className="fixed bottom-0 left-0 right-0 bg-white/90 backdrop-blur-lg border-t border-[#3D405B]/10 monastery-shadow z-50">
      <div className="flex justify-around items-center px-2 py-3">
        {tabs.map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          
          return (
            <button
              key={tab.id}
              onClick={() => onTabChange(tab.id)}
              className={`flex flex-col items-center space-y-1 px-3 py-1 rounded-lg transition-all duration-200 ${
                isActive 
                  ? 'text-[#E07A5F] bg-[#E07A5F]/10' 
                  : 'text-[#3D405B]/60 hover:text-[#3D405B] hover:bg-[#F4F1DE]/50'
              }`}
            >
              <Icon size={20} className={`transition-transform duration-200 ${isActive ? 'scale-110' : ''}`} />
              <span className="text-xs font-medium">{tab.label}</span>
            </button>
          );
        })}
      </div>
    </div>
  );
}