import { X, User, Settings, HelpCircle, LogOut, Bell, Globe, Palette, Star, Trophy, MapPin, Camera } from 'lucide-react';
import { Card, CardContent } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from './ui/avatar';
import { Separator } from './ui/separator';
import { Switch } from './ui/switch';
import { Progress } from './ui/progress';

interface SidePanelProps {
  isOpen: boolean;
  onClose: () => void;
}

export function SidePanel({ isOpen, onClose }: SidePanelProps) {
  const userStats = {
    name: 'Tenzin Explorer',
    email: 'tenzin@monastery-explorer.com',
    level: 'Mindful Wanderer',
    points: 1650,
    nextLevelPoints: 2000,
    visitedMonasteries: 12,
    completedTours: 8,
    eventsAttended: 5,
    currentStreak: 7
  };

  const progress = (userStats.points / userStats.nextLevelPoints) * 100;

  const menuItems = [
    { icon: Settings, label: 'Settings', action: () => {} },
    { icon: Bell, label: 'Notifications', action: () => {}, toggle: true, enabled: true },
    { icon: Globe, label: 'Language', action: () => {}, subtitle: 'English' },
    { icon: Palette, label: 'Theme', action: () => {}, toggle: true, enabled: false },
    { icon: HelpCircle, label: 'Help & Support', action: () => {} },
  ];

  return (
    <>
      {/* Backdrop */}
      {isOpen && (
        <div 
          className="fixed inset-0 bg-black/50 backdrop-blur-sm z-40 transition-opacity duration-300"
          onClick={onClose}
        />
      )}
      
      {/* Side Panel */}
      <div 
        className={`fixed top-0 left-0 h-full w-80 bg-white/95 backdrop-blur-lg border-r border-[#3D405B]/10 z-50 transform transition-transform duration-300 ease-in-out monastery-shadow ${
          isOpen ? 'translate-x-0' : '-translate-x-full'
        }`}
      >
        <div className="flex flex-col h-full">
          {/* Header */}
          <div className="flex items-center justify-between p-6 bg-gradient-to-r from-[#3D405B] to-[#E07A5F]">
            <h2 className="text-white font-medium">Profile</h2>
            <Button
              variant="ghost"
              size="sm"
              onClick={onClose}
              className="text-white hover:bg-white/20"
            >
              <X size={20} />
            </Button>
          </div>

          <div className="flex-1 overflow-y-auto">
            {/* User Profile Section */}
            <div className="p-6">
              <Card className="monastery-card monastery-shadow">
                <CardContent className="p-6">
                  <div className="flex items-center space-x-4 mb-4">
                    <Avatar className="w-16 h-16">
                      <AvatarFallback className="bg-[#E07A5F] text-white text-lg">
                        {userStats.name.split(' ').map(n => n[0]).join('')}
                      </AvatarFallback>
                    </Avatar>
                    <div className="flex-1">
                      <h3 className="text-[#3D405B] font-medium text-lg">{userStats.name}</h3>
                      <p className="text-[#3D405B]/60 text-sm mb-2">{userStats.email}</p>
                      <Badge className="bg-[#F2CC8F] text-[#3D405B]">{userStats.level}</Badge>
                    </div>
                  </div>

                  {/* Level Progress */}
                  <div className="mb-4">
                    <div className="flex justify-between text-sm mb-2">
                      <span className="text-[#3D405B]/80">Level Progress</span>
                      <span className="text-[#3D405B]/80">{userStats.points}/{userStats.nextLevelPoints} pts</span>
                    </div>
                    <Progress value={progress} className="h-2" />
                    <p className="text-[#3D405B]/60 text-xs mt-1">
                      {userStats.nextLevelPoints - userStats.points} points to next level
                    </p>
                  </div>

                  {/* Quick Stats */}
                  <div className="grid grid-cols-2 gap-3">
                    <div className="text-center p-3 bg-[#F4F1DE]/50 rounded-lg">
                      <MapPin className="text-[#E07A5F] mx-auto mb-1" size={16} />
                      <div className="text-[#3D405B] font-medium">{userStats.visitedMonasteries}</div>
                      <div className="text-[#3D405B]/60 text-xs">Visited</div>
                    </div>
                    <div className="text-center p-3 bg-[#F4F1DE]/50 rounded-lg">
                      <Camera className="text-[#E07A5F] mx-auto mb-1" size={16} />
                      <div className="text-[#3D405B] font-medium">{userStats.completedTours}</div>
                      <div className="text-[#3D405B]/60 text-xs">Tours</div>
                    </div>
                    <div className="text-center p-3 bg-[#F4F1DE]/50 rounded-lg">
                      <Star className="text-[#E07A5F] mx-auto mb-1" size={16} />
                      <div className="text-[#3D405B] font-medium">{userStats.eventsAttended}</div>
                      <div className="text-[#3D405B]/60 text-xs">Events</div>
                    </div>
                    <div className="text-center p-3 bg-[#F4F1DE]/50 rounded-lg">
                      <Trophy className="text-[#E07A5F] mx-auto mb-1" size={16} />
                      <div className="text-[#3D405B] font-medium">{userStats.currentStreak}</div>
                      <div className="text-[#3D405B]/60 text-xs">Day Streak</div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            <Separator className="mx-6" />

            {/* Menu Items */}
            <div className="p-6 space-y-2">
              {menuItems.map((item, index) => {
                const Icon = item.icon;
                return (
                  <div
                    key={index}
                    className="flex items-center justify-between p-3 rounded-lg hover:bg-[#F4F1DE]/50 cursor-pointer transition-colors"
                    onClick={item.action}
                  >
                    <div className="flex items-center space-x-3">
                      <Icon className="text-[#3D405B]/60" size={20} />
                      <div>
                        <span className="text-[#3D405B] font-medium">{item.label}</span>
                        {item.subtitle && (
                          <p className="text-[#3D405B]/60 text-sm">{item.subtitle}</p>
                        )}
                      </div>
                    </div>
                    {item.toggle && (
                      <Switch 
                        checked={item.enabled} 
                        onCheckedChange={() => {}}
                      />
                    )}
                  </div>
                );
              })}
            </div>

            <Separator className="mx-6" />

            {/* Recent Achievements */}
            <div className="p-6">
              <h4 className="text-[#3D405B] font-medium mb-3">Recent Achievements</h4>
              <div className="space-y-2">
                <div className="flex items-center space-x-3 p-2 bg-[#F2CC8F]/20 rounded-lg">
                  <div className="w-8 h-8 bg-[#E07A5F] rounded-full flex items-center justify-center">
                    <Star className="text-white" size={14} />
                  </div>
                  <div className="flex-1">
                    <p className="text-[#3D405B] text-sm font-medium">First Tour Completed</p>
                    <p className="text-[#3D405B]/60 text-xs">Completed your first 360° tour</p>
                  </div>
                  <Badge className="bg-[#F2CC8F] text-[#3D405B] text-xs">+50pts</Badge>
                </div>
                
                <div className="flex items-center space-x-3 p-2 bg-[#F2CC8F]/20 rounded-lg">
                  <div className="w-8 h-8 bg-[#E07A5F] rounded-full flex items-center justify-center">
                    <MapPin className="text-white" size={14} />
                  </div>
                  <div className="flex-1">
                    <p className="text-[#3D405B] text-sm font-medium">Explorer Badge</p>
                    <p className="text-[#3D405B]/60 text-xs">Visited 10 different monasteries</p>
                  </div>
                  <Badge className="bg-[#F2CC8F] text-[#3D405B] text-xs">+100pts</Badge>
                </div>
              </div>
            </div>
          </div>

          {/* Footer */}
          <div className="p-6 border-t border-[#3D405B]/10">
            <Button
              variant="outline"
              className="w-full border-[#E07A5F] text-[#E07A5F] hover:bg-[#E07A5F] hover:text-white"
              onClick={() => {}}
            >
              <LogOut className="mr-2" size={16} />
              Sign Out
            </Button>
          </div>
        </div>
      </div>
    </>
  );
}