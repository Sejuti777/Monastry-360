import { Search, Compass, Star, Calendar, Camera, MessageSquare, Menu } from 'lucide-react';
import { Card, CardContent } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { ImageWithFallback } from './figma/ImageWithFallback';

interface HomeScreenProps {
  onTabChange: (tab: string) => void;
  onMenuClick: () => void;
}

export function HomeScreen({ onTabChange, onMenuClick }: HomeScreenProps) {
  const quickActions = [
    { id: 'map', label: 'Explore Map', icon: Compass, description: 'Find monasteries near you' },
    { id: 'tours', label: 'Virtual Tours', icon: Camera, description: 'Immersive 360° experiences' },
    { id: 'planner', label: 'Plan Journey', icon: MessageSquare, description: 'AI-powered trip planning' },
    { id: 'calendar', label: 'Festivals', icon: Calendar, description: 'Sacred calendar events' },
  ];

  const featuredMonasteries = [
    {
      id: 1,
      name: 'Potala Palace',
      location: 'Lhasa, Tibet',
      image: 'https://images.unsplash.com/photo-1629646621053-458c7ab125a9?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx0aWJldGFuJTIwbW9uYXN0ZXJ5JTIwbW91bnRhaW58ZW58MXx8fHwxNzU3ODM0MzI1fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
      rating: 4.9,
      description: 'Former residence of the Dalai Lama'
    },
    {
      id: 2,
      name: 'Kinkaku-ji',
      location: 'Kyoto, Japan',
      image: 'https://images.unsplash.com/photo-1662792932656-a5491f28b91d?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHxqYXBhbmVzZSUyMHRlbXBsZSUyMHplbnxlbnwxfHx8fDE3NTc4MzQzMjh8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
      rating: 4.8,
      description: 'Golden Pavilion surrounded by gardens'
    },
    {
      id: 3,
      name: 'Monastery of the Cross',
      location: 'Jerusalem',
      image: 'https://images.unsplash.com/photo-1717738979611-6e62e17cbe85?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxidWRkaGlzdCUyMG1vbmFzdGVyeSUyMGFyY2hpdGVjdHVyZXxlbnwxfHx8fDE3NTc4MzQzMzB8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
      rating: 4.7,
      description: 'Historic Orthodox monastery'
    },
  ];

  return (
    <div className="pb-20 min-h-screen bg-gradient-to-b from-[#F4F1DE] to-white">
      {/* Header */}
      <div className="relative overflow-hidden px-6 pt-12 pb-8" style={{ background: 'linear-gradient(to right, #f48d0fff, #ffd89b)' }}>
        <div className="absolute top-0 right-0 w-32 h-32 opacity-10">
          <div className="mandala-border w-full h-full rounded-full bg-white/20"></div>
        </div>
        <div className="prayer-flag absolute top-4 right-8 w-8 h-6 bg-[#F2CC8F] rounded-sm opacity-30"></div>

        {/* Menu Button */}
        <Button
          variant="ghost"
          size="sm"
          onClick={onMenuClick}
          className="absolute top-2 left-2 text-white hover:bg-white/20"
        >
          <Menu size={24} />
        </Button>

        <div className="flex items-center gap-3 mb-2 mt-12">
          <img src="src\components\applogo.png" alt="App Logo" className="w-20 h-20" />
          <div>
            <h1 className="text-white text-2xl font-bold">Welcome to</h1>
            <h2 className="text-3xl font-bold accent-text" style={{ color: '#6e2204ff' }}>Monastery Explorer</h2>
          </div>
        </div>
        <p className="text-white/80 text-sm mb-6">Discover sacred spaces, immerse in culture, plan your spiritual journey</p>

        {/* Search Bar */}
        <div className="relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-[#3D405B]/60" size={20} />
          <Input
            placeholder="Search monasteries, temples, or locations..."
            className="pl-10 bg-white/90 border-white/20 text-[#3D405B] placeholder:text-[#3D405B]/60"
          />
        </div>
      </div>

      {/* Quick Actions */}
      <div className="px-6 py-6">
        <h3 className="text-[#3D405B] mb-4">Quick Actions</h3>
        <div className="grid grid-cols-2 gap-4">
          {quickActions.map((action) => {
            const Icon = action.icon;
            return (
              <Card
                key={action.id}
                className="monastery-card monastery-shadow cursor-pointer hover:scale-105 transition-transform duration-200"
                onClick={() => onTabChange(action.id)}
              >
                <CardContent className="p-4 text-center">
                  <div className="bg-[#E07A5F]/10 w-12 h-12 rounded-full flex items-center justify-center mx-auto mb-3">
                    <Icon className="text-[#E07A5F]" size={24} />
                  </div>
                  <h4 className="text-[#3D405B] font-medium mb-1">{action.label}</h4>
                  <p className="text-[#3D405B]/60 text-xs">{action.description}</p>
                </CardContent>
              </Card>
            );
          })}
        </div>
      </div>

      {/* Featured Monasteries */}
      <div className="px-6 py-2">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-[#3D405B]">Featured Monasteries</h3>
          <Button variant="ghost" className="text-[#E07A5F] text-sm p-0">View All</Button>
        </div>

        <div className="space-y-4">
          {featuredMonasteries.map((monastery) => (
            <Card key={monastery.id} className="monastery-card monastery-shadow cursor-pointer hover:scale-[1.02] transition-transform duration-200">
              <CardContent className="p-0">
                <div className="flex">
                  <div className="relative w-24 h-24 rounded-l-lg overflow-hidden">
                    <ImageWithFallback
                      src={monastery.image}
                      alt={monastery.name}
                      className="w-full h-full object-cover"
                    />
                    <div className="absolute inset-0 bg-gradient-to-r from-transparent to-black/20"></div>
                  </div>
                  <div className="flex-1 p-4">
                    <div className="flex items-start justify-between mb-1">
                      <h4 className="text-[#3D405B] font-medium text-sm">{monastery.name}</h4>
                      <div className="flex items-center space-x-1">
                        <Star className="text-[#F2CC8F] fill-current" size={12} />
                        <span className="text-[#3D405B] text-xs">{monastery.rating}</span>
                      </div>
                    </div>
                    <p className="text-[#3D405B]/60 text-xs mb-2">{monastery.location}</p>
                    <p className="text-[#3D405B]/80 text-xs accent-text">{monastery.description}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </div>
  );
}