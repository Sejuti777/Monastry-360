import { MapPin, Filter, Search, Navigation, Menu, ArrowLeft, Map, List, Navigation2, X, Route, Users, Mountain, Clock } from 'lucide-react';
import { Card, CardContent } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Badge } from './ui/badge';
import { useState, useMemo } from 'react';
import LeafletMap from './LeafletMap';
import { MonasteryFilters } from './MonasteryFilters';
import { RoutePlanner } from './RoutePlanner';
import { useLocation } from '../hooks/useLocation';
import { sikkimMonasteries, Monastery } from '../data/monasteries';

interface MapScreenProps {
  onMenuClick: () => void;
  onBackClick: () => void;
}

export function MapScreen({ onMenuClick, onBackClick }: MapScreenProps) {
  const [viewMode, setViewMode] = useState<'map' | 'list'>('map');
  const [selectedMonastery, setSelectedMonastery] = useState<Monastery | null>(null);
  const [filteredMonasteries, setFilteredMonasteries] = useState<Monastery[]>(sikkimMonasteries);
  const [searchQuery, setSearchQuery] = useState('');
  const [showFilters, setShowFilters] = useState(false);
  const [showRoutePlanner, setShowRoutePlanner] = useState(false);

  const {
    latitude,
    longitude,
    error: locationError,
    loading: locationLoading,
    getCurrentLocation,
    hasLocation
  } = useLocation();

  const userLocation = hasLocation ? { lat: latitude!, lng: longitude! } : null;

  const handleMonasterySelect = (monastery: Monastery) => {
    setSelectedMonastery(monastery);
    setViewMode('list'); // Switch to list view to show details
  };

  const handleFilterChange = (monasteries: Monastery[]) => {
    setFilteredMonasteries(monasteries);
  };

  const handleSearchChange = (query: string) => {
    setSearchQuery(query);
  };

  const getDistanceFromUser = (monastery: Monastery) => {
    if (!userLocation) return null;

    const R = 6371; // Earth's radius in kilometers
    const dLat = (monastery.lat - userLocation.lat) * Math.PI / 180;
    const dLng = (monastery.lng - userLocation.lng) * Math.PI / 180;
    const a =
      Math.sin(dLat / 2) * Math.sin(dLat / 2) +
      Math.cos(userLocation.lat * Math.PI / 180) * Math.cos(monastery.lat * Math.PI / 180) *
      Math.sin(dLng / 2) * Math.sin(dLng / 2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    return Math.round(R * c * 10) / 10; // Round to 1 decimal place
  };

  return (
    <div className="pb-20 min-h-screen bg-[#F4F1DE]">
      {/* Header */}
      <div className="bg-white/90 backdrop-blur-lg px-6 py-4 border-b border-[#3D405B]/10 sticky top-0 z-40">
        <div className="flex items-center space-x-3 mb-4 pt-2">
          <Button
            variant="ghost"
            size="sm"
            onClick={onMenuClick}
            className="text-[#3D405B] hover:bg-[#F4F1DE]/50"
          >
            <Menu size={20} />
          </Button>
          <Button
            variant="ghost"
            size="sm"
            onClick={onBackClick}
            className="text-[#3D405B] hover:bg-[#F4F1DE]/50"
          >
            <ArrowLeft size={20} />
          </Button>

          {/* Search and Filters */}
          <div className="flex-1">
            <MonasteryFilters
              onFilterChange={handleFilterChange}
              onSearchChange={handleSearchChange}
            />
          </div>

          {/* Location Button */}
          <Button
            size="sm"
            variant="outline"
            className="border-[#3D405B]/20"
            onClick={getCurrentLocation}
            disabled={locationLoading}
            title="Detect my location"
          >
            <Navigation2 size={16} />
          </Button>

          {/* Route Planner Button */}
          <Button
            size="sm"
            variant="outline"
            className="border-[#3D405B]/20"
            onClick={() => setShowRoutePlanner(!showRoutePlanner)}
            title="Plan route to all monasteries"
          >
            <Route size={16} />
          </Button>

          {/* View Toggle */}
          <div className="flex border border-[#3D405B]/20 rounded-lg">
            <Button
              size="sm"
              variant={viewMode === 'map' ? 'default' : 'ghost'}
              className={`rounded-r-none ${viewMode === 'map'
                ? 'bg-[#E07A5F] text-white'
                : 'text-[#3D405B] hover:bg-[#F4F1DE]/50'
                }`}
              onClick={() => setViewMode('map')}
            >
              <Map size={16} />
            </Button>
            <Button
              size="sm"
              variant={viewMode === 'list' ? 'default' : 'ghost'}
              className={`rounded-l-none border-l ${viewMode === 'list'
                ? 'bg-[#E07A5F] text-white'
                : 'text-[#3D405B] hover:bg-[#F4F1DE]/50'
                }`}
              onClick={() => setViewMode('list')}
            >
              <List size={16} />
            </Button>
          </div>
        </div>

        {/* Location Status */}
        {hasLocation && (
          <div className="flex items-center space-x-2 text-xs text-[#3D405B]/70">
            <div className="w-2 h-2 bg-green-500 rounded-full"></div>
            <span>Location detected</span>
          </div>
        )}
        {locationError && (
          <div className="flex items-center space-x-2 text-xs text-red-600">
            <div className="w-2 h-2 bg-red-500 rounded-full"></div>
            <span>Location access denied</span>
          </div>
        )}
      </div>

      {/* Main Content Area */}
      <div className="mx-6 my-4">
        {viewMode === 'map' ? (
          /* Interactive Leaflet Map (Free OpenStreetMap) */
          <div className="relative h-96 rounded-xl overflow-hidden monastery-shadow">
            <LeafletMap
              selectedMonastery={selectedMonastery}
              onMonasterySelect={handleMonasterySelect}
              userLocation={userLocation}
              searchQuery={searchQuery}
              filteredMonasteries={filteredMonasteries}
            />
          </div>
        ) : (
          /* Monastery List View */
          <div className="space-y-4">
            {selectedMonastery && (
              /* Selected Monastery Details */
              <Card className="monastery-card monastery-shadow border-[#E07A5F]/20">
                <CardContent className="p-6">
                  <div className="flex items-start justify-between mb-4">
                    <div>
                      <h2 className="text-xl font-semibold text-[#3D405B] mb-1">
                        {selectedMonastery.name}
                      </h2>
                      <p className="text-[#3D405B]/70 text-sm">{selectedMonastery.type}</p>
                    </div>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => setSelectedMonastery(null)}
                      className="text-[#3D405B]/60 hover:text-[#E07A5F]"
                    >
                      <X size={16} />
                    </Button>
                  </div>

                  <p className="text-[#3D405B]/80 text-sm mb-4">{selectedMonastery.description}</p>

                  <div className="grid grid-cols-2 gap-4 mb-4">
                    <div className="flex items-center space-x-2">
                      <MapPin className="text-[#E07A5F]" size={16} />
                      <span className="text-[#3D405B]/70 text-xs">{selectedMonastery.altitude}</span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Users className="text-[#E07A5F]" size={16} />
                      <span className="text-[#3D405B]/70 text-xs">{selectedMonastery.visitors} visitors/month</span>
                    </div>
                    {selectedMonastery.founded && (
                      <div className="flex items-center space-x-2">
                        <Clock className="text-[#E07A5F]" size={16} />
                        <span className="text-[#3D405B]/70 text-xs">Founded {selectedMonastery.founded}</span>
                      </div>
                    )}
                    {selectedMonastery.sect && (
                      <div className="flex items-center space-x-2">
                        <div className="w-3 h-3 bg-[#E07A5F] rounded-full"></div>
                        <span className="text-[#3D405B]/70 text-xs">{selectedMonastery.sect} Sect</span>
                      </div>
                    )}
                  </div>

                  {selectedMonastery.features.length > 0 && (
                    <div className="mb-4">
                      <h4 className="text-[#3D405B] font-medium text-sm mb-2">Features</h4>
                      <div className="flex flex-wrap gap-2">
                        {selectedMonastery.features.map((feature, index) => (
                          <Badge key={index} variant="secondary" className="bg-[#F2CC8F]/30 text-[#3D405B] text-xs">
                            {feature}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  )}

                  {selectedMonastery.nearbyAttractions.length > 0 && (
                    <div className="mb-4">
                      <h4 className="text-[#3D405B] font-medium text-sm mb-2">Nearby Attractions</h4>
                      <div className="flex flex-wrap gap-2">
                        {selectedMonastery.nearbyAttractions.map((attraction, index) => (
                          <Badge key={index} variant="outline" className="border-[#3D405B]/20 text-[#3D405B] text-xs">
                            {attraction}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  )}

                  <div className="flex space-x-3">
                    <Button className="bg-[#E07A5F] hover:bg-[#E07A5F]/90 text-white flex-1">
                      Plan Visit
                    </Button>
                    <Button variant="outline" className="border-[#3D405B]/20 text-[#3D405B] flex-1">
                      Get Directions
                    </Button>
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Monastery List */}
            <div>
              <h3 className="text-[#3D405B] mb-4 flex items-center">
                Monasteries in Sikkim
                <Badge className="ml-2 bg-[#F2CC8F] text-[#3D405B]">{filteredMonasteries.length}</Badge>
              </h3>

              <div className="space-y-3">
                {filteredMonasteries.map((monastery) => {
                  const distance = getDistanceFromUser(monastery);
                  return (
                    <Card
                      key={monastery.id}
                      className={`monastery-card monastery-shadow cursor-pointer transition-all hover:shadow-lg ${selectedMonastery?.id === monastery.id ? 'ring-2 ring-[#E07A5F]/50' : ''
                        }`}
                      onClick={() => handleMonasterySelect(monastery)}
                    >
                      <CardContent className="p-4">
                        <div className="flex items-center justify-between">
                          <div className="flex-1">
                            <div className="flex items-center space-x-2 mb-1">
                              <MapPin className="text-[#E07A5F]" size={16} />
                              <h4 className="text-[#3D405B] font-medium">{monastery.name}</h4>
                            </div>
                            <p className="text-[#3D405B]/60 text-sm mb-2">{monastery.type}</p>
                            <div className="flex items-center space-x-3">
                              <span className="text-[#3D405B]/80 text-xs">
                                {monastery.visitors} monthly visitors
                              </span>
                              <span className="text-[#3D405B]/70 text-xs">
                                {monastery.altitude}
                              </span>
                              {distance && (
                                <Badge variant="secondary" className="bg-[#F2CC8F]/30 text-[#3D405B] text-xs">
                                  {distance} km away
                                </Badge>
                              )}
                            </div>
                          </div>
                          <div className="flex flex-col space-y-2">
                            <Button
                              size="sm"
                              className="bg-[#E07A5F] hover:bg-[#E07A5F]/90 text-white"
                              onClick={(e) => {
                                e.stopPropagation();
                                handleMonasterySelect(monastery);
                              }}
                            >
                              View
                            </Button>
                            <Button
                              size="sm"
                              variant="outline"
                              className="border-[#3D405B]/20 text-[#3D405B]"
                              onClick={(e) => {
                                e.stopPropagation();
                                setViewMode('map');
                                handleMonasterySelect(monastery);
                              }}
                            >
                              Map
                            </Button>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  );
                })}
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Route Planner */}
      {showRoutePlanner && (
        <RoutePlanner
          userLocation={userLocation}
          onClose={() => setShowRoutePlanner(false)}
        />
      )}

    </div>
  );
}