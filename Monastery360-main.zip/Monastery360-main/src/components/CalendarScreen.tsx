import { ChevronLeft, ChevronRight, MapPin, Clock, Users, Menu, ArrowLeft } from 'lucide-react';
import { Card, CardContent } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { useState } from 'react';

interface CalendarScreenProps {
  onMenuClick: () => void;
  onBackClick: () => void;
}

export function CalendarScreen({ onMenuClick, onBackClick }: CalendarScreenProps) {
  const [currentDate, setCurrentDate] = useState(new Date(2024, 8)); // September 2024

  const events = [
    {
      id: 1,
      title: 'Mid-Autumn Festival',
      date: 15,
      month: 8,
      category: 'Buddhist',
      location: 'Various Temples',
      time: 'All Day',
      attendees: 1200,
      color: 'bg-[#E07A5F]'
    },
    {
      id: 2,
      title: 'Pchum Ben Festival',
      date: 18,
      month: 8,
      category: 'Buddhist',
      location: 'Cambodia',
      time: '6:00 AM',
      attendees: 800,
      color: 'bg-[#F2CC8F]'
    },
    {
      id: 3,
      title: 'Autumn Meditation Retreat',
      date: 22,
      month: 8,
      category: 'Meditation',
      location: 'Sera Monastery',
      time: '9:00 AM',
      attendees: 45,
      color: 'bg-[#3D405B]'
    },
    {
      id: 4,
      title: 'Full Moon Ceremony',
      date: 28,
      month: 8,
      category: 'Ceremony',
      location: 'Jokhang Temple',
      time: '8:00 PM',
      attendees: 300,
      color: 'bg-[#E07A5F]'
    }
  ];

  const categories = [
    { name: 'All', color: 'bg-[#3D405B]', count: 12 },
    { name: 'Buddhist', color: 'bg-[#E07A5F]', count: 8 },
    { name: 'Meditation', color: 'bg-[#F2CC8F]', count: 3 },
    { name: 'Ceremony', color: 'bg-[#3D405B]', count: 1 }
  ];

  const monthNames = [
    'January', 'February', 'March', 'April', 'May', 'June',
    'July', 'August', 'September', 'October', 'November', 'December'
  ];

  const daysInMonth = new Date(currentDate.getFullYear(), currentDate.getMonth() + 1, 0).getDate();
  const firstDayOfMonth = new Date(currentDate.getFullYear(), currentDate.getMonth(), 1).getDay();
  const days = Array.from({ length: daysInMonth }, (_, i) => i + 1);
  const emptyDays = Array.from({ length: firstDayOfMonth }, (_, i) => i);

  const getEventForDay = (day: number) => {
    return events.find(event => event.date === day && event.month === currentDate.getMonth());
  };

  const navigateMonth = (direction: number) => {
    setCurrentDate(new Date(currentDate.getFullYear(), currentDate.getMonth() + direction));
  };

  return (
    <div className="pb-20 min-h-screen bg-[#F4F1DE]">
      {/* Header */}
      <div className="bg-gradient-to-r from-[#3D405B] to-[#E07A5F] px-6 py-6 relative">
        <div className="flex items-center gap-2 absolute top-2 left-4">
          <Button
            variant="ghost"
            size="sm"
            onClick={onMenuClick}
            className="text-white hover:bg-white/20"
          >
            <Menu size={20} />
          </Button>
          <Button
            variant="ghost"
            size="sm"
            onClick={onBackClick}
            className="text-white hover:bg-white/20"
          >
            <ArrowLeft size={20} />
          </Button>
        </div>
        <div className="mt-10">
          <h1 className="text-white text-2xl font-bold mb-2">Sacred Calendar</h1>
          <p className="text-white/80 text-sm">Festivals, ceremonies, and spiritual events</p>
        </div>
      </div>

      {/* Categories */}
      <div className="px-6 py-4 bg-white/90 backdrop-blur-lg border-b border-[#3D405B]/10">
        <div className="flex space-x-2 overflow-x-auto pb-2">
          {categories.map((category, index) => (
            <Badge 
              key={category.name} 
              variant={index === 0 ? "default" : "secondary"}
              className={`whitespace-nowrap ${
                index === 0 
                  ? 'bg-[#E07A5F] text-white hover:bg-[#E07A5F]/90' 
                  : 'bg-[#F2CC8F]/30 text-[#3D405B] hover:bg-[#F2CC8F]/50'
              }`}
            >
              {category.name} ({category.count})
            </Badge>
          ))}
        </div>
      </div>

      {/* Calendar Navigation */}
      <div className="px-6 py-4">
        <div className="flex items-center justify-between mb-4">
          <Button 
            variant="outline" 
            size="sm"
            onClick={() => navigateMonth(-1)}
            className="border-[#3D405B]/20"
          >
            <ChevronLeft size={16} />
          </Button>
          <h3 className="text-[#3D405B] text-lg font-medium">
            {monthNames[currentDate.getMonth()]} {currentDate.getFullYear()}
          </h3>
          <Button 
            variant="outline" 
            size="sm"
            onClick={() => navigateMonth(1)}
            className="border-[#3D405B]/20"
          >
            <ChevronRight size={16} />
          </Button>
        </div>

        {/* Calendar Grid */}
        <Card className="monastery-shadow overflow-hidden">
          <CardContent className="p-0">
            {/* Day Headers */}
            <div className="grid grid-cols-7 bg-[#F2CC8F]/20">
              {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map((day) => (
                <div key={day} className="p-3 text-center text-[#3D405B] text-sm font-medium">
                  {day}
                </div>
              ))}
            </div>
            
            {/* Calendar Days */}
            <div className="grid grid-cols-7">
              {emptyDays.map((_, index) => (
                <div key={`empty-${index}`} className="h-12 border-r border-b border-[#3D405B]/10"></div>
              ))}
              {days.map((day) => {
                const event = getEventForDay(day);
                return (
                  <div 
                    key={day} 
                    className="h-12 border-r border-b border-[#3D405B]/10 p-1 relative hover:bg-[#F4F1DE]/50 cursor-pointer"
                  >
                    <span className="text-[#3D405B] text-sm">{day}</span>
                    {event && (
                      <div className={`absolute bottom-1 left-1 right-1 h-1 ${event.color} rounded-full opacity-80`}></div>
                    )}
                  </div>
                );
              })}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Upcoming Events */}
      <div className="px-6">
        <h3 className="text-[#3D405B] mb-4">Upcoming Events</h3>
        <div className="space-y-3">
          {events.map((event) => (
            <Card key={event.id} className="monastery-card monastery-shadow">
              <CardContent className="p-4">
                <div className="flex items-start space-x-3">
                  <div className="text-center min-w-[60px]">
                    <div className="text-[#3D405B] text-lg font-bold">{event.date}</div>
                    <div className="text-[#3D405B]/60 text-xs uppercase">
                      {monthNames[event.month].slice(0, 3)}
                    </div>
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center space-x-2 mb-1">
                      <h4 className="text-[#3D405B] font-medium">{event.title}</h4>
                      <Badge 
                        className={`${event.color} text-white text-xs`}
                      >
                        {event.category}
                      </Badge>
                    </div>
                    <div className="flex items-center text-[#3D405B]/60 text-sm space-x-3 mb-2">
                      <div className="flex items-center space-x-1">
                        <MapPin size={12} />
                        <span>{event.location}</span>
                      </div>
                      <div className="flex items-center space-x-1">
                        <Clock size={12} />
                        <span>{event.time}</span>
                      </div>
                    </div>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-1 text-[#3D405B]/80 text-xs">
                        <Users size={12} />
                        <span>{event.attendees} attending</span>
                      </div>
                      <Button size="sm" variant="outline" className="border-[#E07A5F] text-[#E07A5F] h-7">
                        Join
                      </Button>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </div>
  );
}