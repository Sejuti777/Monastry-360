import React, { useState } from 'react';
import { Route, MapPin, Navigation, Clock, Users, X } from 'lucide-react';
import { Button } from './ui/button';
import { Card, CardContent } from './ui/card';
import { Badge } from './ui/badge';
import { sikkimMonasteries, Monastery } from '../data/monasteries';

interface RoutePlannerProps {
    userLocation?: { lat: number; lng: number } | null;
    onClose: () => void;
}

interface RoutePlan {
    monasteries: Monastery[];
    totalDistance: number;
    estimatedTime: string;
    routeOrder: number[];
}

export function RoutePlanner({ userLocation, onClose }: RoutePlannerProps) {
    const [selectedRoute, setSelectedRoute] = useState<RoutePlan | null>(null);
    const [isGenerating, setIsGenerating] = useState(false);

    // Calculate distance between two points using Haversine formula
    const calculateDistance = (lat1: number, lng1: number, lat2: number, lng2: number) => {
        const R = 6371; // Earth's radius in kilometers
        const dLat = (lat2 - lat1) * Math.PI / 180;
        const dLng = (lng2 - lng1) * Math.PI / 180;
        const a =
            Math.sin(dLat / 2) * Math.sin(dLat / 2) +
            Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) *
            Math.sin(dLng / 2) * Math.sin(dLng / 2);
        const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
        return R * c;
    };

    // Generate optimal route using nearest neighbor algorithm
    const generateOptimalRoute = async () => {
        setIsGenerating(true);

        // Simulate API call delay
        await new Promise(resolve => setTimeout(resolve, 2000));

        let startPoint = userLocation ? { lat: userLocation.lat, lng: userLocation.lng } : { lat: 27.3333, lng: 88.6167 };
        let remainingMonasteries = [...sikkimMonasteries];
        let routeOrder: number[] = [];
        let totalDistance = 0;
        let currentPoint = startPoint;

        // Nearest neighbor algorithm
        while (remainingMonasteries.length > 0) {
            let nearestIndex = 0;
            let nearestDistance = calculateDistance(
                currentPoint.lat,
                currentPoint.lng,
                remainingMonasteries[0].lat,
                remainingMonasteries[0].lng
            );

            // Find nearest monastery
            for (let i = 1; i < remainingMonasteries.length; i++) {
                const distance = calculateDistance(
                    currentPoint.lat,
                    currentPoint.lng,
                    remainingMonasteries[i].lat,
                    remainingMonasteries[i].lng
                );

                if (distance < nearestDistance) {
                    nearestDistance = distance;
                    nearestIndex = i;
                }
            }

            // Add to route
            const nearestMonastery = remainingMonasteries[nearestIndex];
            routeOrder.push(nearestMonastery.id);
            totalDistance += nearestDistance;
            currentPoint = { lat: nearestMonastery.lat, lng: nearestMonastery.lng };
            remainingMonasteries.splice(nearestIndex, 1);
        }

        // Calculate estimated time (assuming 40 km/h average speed + 2 hours per monastery)
        const drivingTime = totalDistance / 40; // hours
        const visitingTime = sikkimMonasteries.length * 2; // 2 hours per monastery
        const totalTime = drivingTime + visitingTime;
        const estimatedTime = `${Math.round(totalTime)} hours`;

        const routePlan: RoutePlan = {
            monasteries: sikkimMonasteries,
            totalDistance: Math.round(totalDistance * 10) / 10,
            estimatedTime,
            routeOrder
        };

        setSelectedRoute(routePlan);
        setIsGenerating(false);
    };

    const openRouteInMaps = () => {
        if (!selectedRoute || selectedRoute.routeOrder.length === 0) return;

        // Create waypoints for Google Maps
        const waypoints = selectedRoute.routeOrder
            .map(id => sikkimMonasteries.find(m => m.id === id))
            .filter(Boolean)
            .map(monastery => `${monastery!.lat},${monastery!.lng}`)
            .join('|');

        const destination = waypoints.split('|').pop();
        const url = `https://www.google.com/maps/dir/?api=1&destination=${destination}&waypoints=${waypoints}`;
        window.open(url, '_blank');
    };

    return (
        <Card className="fixed top-4 right-4 w-96 z-50 monastery-shadow">
            <CardContent className="p-4">
                <div className="flex items-center justify-between mb-4">
                    <div className="flex items-center space-x-2">
                        <Route className="text-[#E07A5F]" size={20} />
                        <h3 className="text-[#3D405B] font-semibold">Monastery Route Planner</h3>
                    </div>
                    <Button
                        variant="ghost"
                        size="sm"
                        onClick={onClose}
                        className="text-[#3D405B]/60 hover:text-[#E07A5F]"
                    >
                        <X size={16} />
                    </Button>
                </div>

                {userLocation ? (
                    <div className="mb-4 p-3 bg-green-50 rounded-lg">
                        <div className="flex items-center space-x-2">
                            <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                            <span className="text-green-700 text-sm font-medium">Your location detected</span>
                        </div>
                        <p className="text-green-600 text-xs mt-1">
                            Starting from your current position
                        </p>
                    </div>
                ) : (
                    <div className="mb-4 p-3 bg-yellow-50 rounded-lg">
                        <div className="flex items-center space-x-2">
                            <div className="w-2 h-2 bg-yellow-500 rounded-full"></div>
                            <span className="text-yellow-700 text-sm font-medium">Default starting point</span>
                        </div>
                        <p className="text-yellow-600 text-xs mt-1">
                            Starting from Sikkim center
                        </p>
                    </div>
                )}

                {!selectedRoute ? (
                    <div className="space-y-3">
                        <p className="text-[#3D405B]/70 text-sm">
                            Generate an optimal route to visit all {sikkimMonasteries.length} monasteries in Sikkim.
                        </p>

                        <Button
                            onClick={generateOptimalRoute}
                            disabled={isGenerating}
                            className="w-full bg-[#E07A5F] hover:bg-[#E07A5F]/90 text-white"
                        >
                            {isGenerating ? (
                                <>
                                    <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                                    Generating Route...
                                </>
                            ) : (
                                <>
                                    <Navigation size={16} className="mr-2" />
                                    Generate Optimal Route
                                </>
                            )}
                        </Button>
                    </div>
                ) : (
                    <div className="space-y-4">
                        <div className="grid grid-cols-2 gap-4">
                            <div className="text-center p-3 bg-[#F2CC8F]/20 rounded-lg">
                                <div className="flex items-center justify-center mb-1">
                                    <Route className="text-[#E07A5F]" size={16} />
                                </div>
                                <div className="text-[#3D405B] font-semibold text-lg">{selectedRoute.totalDistance} km</div>
                                <div className="text-[#3D405B]/60 text-xs">Total Distance</div>
                            </div>
                            <div className="text-center p-3 bg-[#F2CC8F]/20 rounded-lg">
                                <div className="flex items-center justify-center mb-1">
                                    <Clock className="text-[#E07A5F]" size={16} />
                                </div>
                                <div className="text-[#3D405B] font-semibold text-lg">{selectedRoute.estimatedTime}</div>
                                <div className="text-[#3D405B]/60 text-xs">Estimated Time</div>
                            </div>
                        </div>

                        <div>
                            <h4 className="text-[#3D405B] font-medium text-sm mb-2 flex items-center">
                                <Users size={14} className="mr-1" />
                                Route Order ({selectedRoute.routeOrder.length} monasteries):
                            </h4>
                            <div className="space-y-2 max-h-40 overflow-y-auto">
                                {selectedRoute.routeOrder.map((monasteryId, index) => {
                                    const monastery = sikkimMonasteries.find(m => m.id === monasteryId);
                                    if (!monastery) return null;

                                    return (
                                        <div key={monasteryId} className="flex items-center space-x-3 p-2 bg-[#F4F1DE]/50 rounded">
                                            <div className="w-6 h-6 bg-[#E07A5F] text-white rounded-full flex items-center justify-center text-xs font-semibold">
                                                {index + 1}
                                            </div>
                                            <div className="flex-1">
                                                <div className="text-[#3D405B] font-medium text-sm">{monastery.name}</div>
                                                <div className="text-[#3D405B]/60 text-xs">{monastery.altitude}</div>
                                            </div>
                                            <MapPin className="text-[#3D405B]/40" size={14} />
                                        </div>
                                    );
                                })}
                            </div>
                        </div>

                        <div className="flex space-x-2">
                            <Button
                                onClick={openRouteInMaps}
                                className="flex-1 bg-[#E07A5F] hover:bg-[#E07A5F]/90 text-white"
                            >
                                <Navigation size={14} className="mr-2" />
                                Open in Maps
                            </Button>
                            <Button
                                variant="outline"
                                onClick={() => setSelectedRoute(null)}
                                className="border-[#3D405B]/20 text-[#3D405B]"
                            >
                                New Route
                            </Button>
                        </div>
                    </div>
                )}
            </CardContent>
        </Card>
    );
}
