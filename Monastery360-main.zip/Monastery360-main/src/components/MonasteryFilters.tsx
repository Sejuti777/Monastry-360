import React, { useState } from 'react';
import { Search, Filter, X, MapPin, Users, Mountain, Clock } from 'lucide-react';
import { Input } from './ui/input';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Card, CardContent } from './ui/card';
import { sikkimMonasteries, Monastery } from '../data/monasteries';

interface MonasteryFiltersProps {
    onFilterChange: (filteredMonasteries: Monastery[]) => void;
    onSearchChange: (query: string) => void;
}

export function MonasteryFilters({ onFilterChange, onSearchChange }: MonasteryFiltersProps) {
    const [searchQuery, setSearchQuery] = useState('');
    const [selectedSect, setSelectedSect] = useState<string>('all');
    const [selectedAltitude, setSelectedAltitude] = useState<string>('all');
    const [showFilters, setShowFilters] = useState(false);

    const sects = ['all', ...Array.from(new Set(sikkimMonasteries.map(m => m.sect).filter(Boolean)))];
    const altitudeRanges = [
        { value: 'all', label: 'All Altitudes' },
        { value: 'low', label: 'Below 5,000 ft' },
        { value: 'medium', label: '5,000 - 7,000 ft' },
        { value: 'high', label: 'Above 7,000 ft' }
    ];

    const filterMonasteries = (query: string, sect: string, altitude: string) => {
        let filtered = sikkimMonasteries;

        // Search filter
        if (query) {
            filtered = filtered.filter(monastery =>
                monastery.name.toLowerCase().includes(query.toLowerCase()) ||
                monastery.type.toLowerCase().includes(query.toLowerCase()) ||
                monastery.description.toLowerCase().includes(query.toLowerCase()) ||
                monastery.sect?.toLowerCase().includes(query.toLowerCase()) ||
                monastery.features.some(feature => feature.toLowerCase().includes(query.toLowerCase()))
            );
        }

        // Sect filter
        if (sect !== 'all') {
            filtered = filtered.filter(monastery => monastery.sect === sect);
        }

        // Altitude filter
        if (altitude !== 'all') {
            filtered = filtered.filter(monastery => {
                const alt = monastery.altitude || '';
                const altValue = parseInt(alt.replace(/[^\d]/g, ''));

                switch (altitude) {
                    case 'low':
                        return altValue < 5000;
                    case 'medium':
                        return altValue >= 5000 && altValue <= 7000;
                    case 'high':
                        return altValue > 7000;
                    default:
                        return true;
                }
            });
        }

        onFilterChange(filtered);
    };

    const handleSearchChange = (value: string) => {
        setSearchQuery(value);
        onSearchChange(value);
        filterMonasteries(value, selectedSect, selectedAltitude);
    };

    const handleSectChange = (sect: string) => {
        setSelectedSect(sect);
        filterMonasteries(searchQuery, sect, selectedAltitude);
    };

    const handleAltitudeChange = (altitude: string) => {
        setSelectedAltitude(altitude);
        filterMonasteries(searchQuery, selectedSect, altitude);
    };

    const clearFilters = () => {
        setSearchQuery('');
        setSelectedSect('all');
        setSelectedAltitude('all');
        onSearchChange('');
        onFilterChange(sikkimMonasteries);
    };

    const hasActiveFilters = searchQuery || selectedSect !== 'all' || selectedAltitude !== 'all';

    return (
        <div className="space-y-4">
            {/* Search Bar */}
            <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-[#3D405B]/60" size={20} />
                <Input
                    placeholder="Search monasteries, features, or locations..."
                    value={searchQuery}
                    onChange={(e) => handleSearchChange(e.target.value)}
                    className="pl-10 bg-white/90 border-[#3D405B]/20 focus:border-[#E07A5F]"
                />
                {searchQuery && (
                    <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => handleSearchChange('')}
                        className="absolute right-2 top-1/2 transform -translate-y-1/2 h-6 w-6 p-0"
                    >
                        <X size={14} />
                    </Button>
                )}
            </div>

            {/* Filter Toggle */}
            <div className="flex items-center justify-between">
                <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setShowFilters(!showFilters)}
                    className="border-[#3D405B]/20 text-[#3D405B] hover:bg-[#F4F1DE]/50"
                >
                    <Filter size={16} className="mr-2" />
                    Filters
                    {hasActiveFilters && (
                        <Badge className="ml-2 bg-[#E07A5F] text-white text-xs">
                            {[searchQuery, selectedSect !== 'all', selectedAltitude !== 'all'].filter(Boolean).length}
                        </Badge>
                    )}
                </Button>

                {hasActiveFilters && (
                    <Button
                        variant="ghost"
                        size="sm"
                        onClick={clearFilters}
                        className="text-[#3D405B]/70 hover:text-[#E07A5F]"
                    >
                        Clear all
                    </Button>
                )}
            </div>

            {/* Filter Panel */}
            {showFilters && (
                <Card className="bg-white/90 border-[#3D405B]/20">
                    <CardContent className="p-4 space-y-4">
                        {/* Sect Filter */}
                        <div>
                            <label className="text-sm font-medium text-[#3D405B] mb-2 block">
                                Buddhist Sect
                            </label>
                            <div className="flex flex-wrap gap-2">
                                {sects.map((sect) => (
                                    <Badge
                                        key={sect}
                                        variant={selectedSect === sect ? "default" : "secondary"}
                                        className={`cursor-pointer transition-colors ${selectedSect === sect
                                                ? 'bg-[#E07A5F] text-white hover:bg-[#E07A5F]/90'
                                                : 'bg-[#F2CC8F]/30 text-[#3D405B] hover:bg-[#F2CC8F]/50'
                                            }`}
                                        onClick={() => handleSectChange(sect)}
                                    >
                                        {sect === 'all' ? 'All Sects' : sect}
                                    </Badge>
                                ))}
                            </div>
                        </div>

                        {/* Altitude Filter */}
                        <div>
                            <label className="text-sm font-medium text-[#3D405B] mb-2 block flex items-center">
                                <Mountain size={16} className="mr-1" />
                                Altitude Range
                            </label>
                            <div className="flex flex-wrap gap-2">
                                {altitudeRanges.map((range) => (
                                    <Badge
                                        key={range.value}
                                        variant={selectedAltitude === range.value ? "default" : "secondary"}
                                        className={`cursor-pointer transition-colors ${selectedAltitude === range.value
                                                ? 'bg-[#E07A5F] text-white hover:bg-[#E07A5F]/90'
                                                : 'bg-[#F2CC8F]/30 text-[#3D405B] hover:bg-[#F2CC8F]/50'
                                            }`}
                                        onClick={() => handleAltitudeChange(range.value)}
                                    >
                                        {range.label}
                                    </Badge>
                                ))}
                            </div>
                        </div>

                        {/* Quick Stats */}
                        <div className="pt-2 border-t border-[#3D405B]/10">
                            <div className="flex items-center justify-between text-xs text-[#3D405B]/70">
                                <span className="flex items-center">
                                    <MapPin size={12} className="mr-1" />
                                    {sikkimMonasteries.length} total monasteries
                                </span>
                                <span className="flex items-center">
                                    <Users size={12} className="mr-1" />
                                    {sikkimMonasteries.reduce((sum, m) => sum + m.visitors, 0).toLocaleString()} monthly visitors
                                </span>
                            </div>
                        </div>
                    </CardContent>
                </Card>
            )}
        </div>
    );
}
