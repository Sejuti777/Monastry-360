import { useState } from 'react';
import { BottomNavigation } from './components/BottomNavigation';
import { HomeScreen } from './components/HomeScreen';
import { MapScreen } from './components/MapScreen';
import { ToursScreen } from './components/ToursScreen';
import { AIPlanner } from './components/AIPlanner';
import { CalendarScreen } from './components/CalendarScreen';
import { CommunityScreen } from './components/CommunityScreen';
import { SidePanel } from './components/SidePanel';

export default function App() {
  const [activeTab, setActiveTab] = useState('home');
  const [isSidePanelOpen, setIsSidePanelOpen] = useState(false);

  const handleMenuClick = () => {
    setIsSidePanelOpen(true);
  };

  const handleCloseSidePanel = () => {
    setIsSidePanelOpen(false);
  };

  const handleBackToHome = () => {
    setActiveTab('home');
  };

  const renderScreen = () => {
    switch (activeTab) {
      case 'map':
        return <MapScreen onMenuClick={handleMenuClick} onBackClick={handleBackToHome} />;
      case 'tours':
        return <ToursScreen onMenuClick={handleMenuClick} onBackClick={handleBackToHome} />;
      case 'planner':
        return <AIPlanner onMenuClick={handleMenuClick} onBackClick={handleBackToHome} />;
      case 'calendar':
        return <CalendarScreen onMenuClick={handleMenuClick} onBackClick={handleBackToHome} />;
      case 'community':
        return <CommunityScreen onMenuClick={handleMenuClick} onBackClick={handleBackToHome} />;
      default:
        return <HomeScreen onTabChange={setActiveTab} onMenuClick={handleMenuClick} />;
    }
  };

  return (
    <div className="min-h-screen bg-[#F4F1DE] font-['Inter',sans-serif] relative">
      {/* Side Panel */}
      <SidePanel isOpen={isSidePanelOpen} onClose={handleCloseSidePanel} />

      {/* Main Content */}
      <main className="relative z-10">
        {renderScreen()}
      </main>

      {/* Bottom Navigation */}
      <BottomNavigation activeTab={activeTab} onTabChange={setActiveTab} />

      {/* Background Decorative Elements */}
      <div className="fixed inset-0 pointer-events-none z-0">
        {/* Subtle mandala pattern in background */}
        <div className="absolute top-20 right-8 w-32 h-32 opacity-5 mandala-border rounded-full bg-gradient-conic from-[#E07A5F] via-[#F2CC8F] to-[#3D405B]"></div>
        <div className="absolute bottom-40 left-4 w-24 h-24 opacity-5 mandala-border rounded-full bg-gradient-conic from-[#3D405B] via-[#E07A5F] to-[#F2CC8F]"></div>
        
        {/* Prayer flags */}
        <div className="absolute top-16 left-12 prayer-flag w-6 h-4 bg-[#E07A5F] opacity-20 rounded-sm"></div>
        <div className="absolute top-24 left-20 prayer-flag w-6 h-4 bg-[#F2CC8F] opacity-20 rounded-sm" style={{ animationDelay: '1s' }}></div>
        <div className="absolute top-32 left-28 prayer-flag w-6 h-4 bg-[#3D405B] opacity-20 rounded-sm" style={{ animationDelay: '2s' }}></div>
      </div>
    </div>
  );
}